﻿using EmailGonderme.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;

namespace EmailGonderme.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(Email model, HttpPostedFileBase myFiles)
        {
            MailMessage mailim = new MailMessage();
            mailim.To.Add("fbetulyilmaz1@gmail.com");
            mailim.From = new MailAddress("fbetulyilmaz1@gmail.com");
            mailim.Subject = "Bize Ulaşın Sayfasından Mesajınız Var. "+model.Baslik;
            mailim.Body = "Sayın yetkili, "+ model.AdSoyad + " kişisinden gelen mesajın içeriği aşağıdaki gibidir. <br>"+model.Icerik;
            mailim.IsBodyHtml = true;

            if (myFiles != null)
            {
                mailim.Attachments.Add(new Attachment(myFiles.InputStream, myFiles.FileName));
            }

            SmtpClient smtp = new SmtpClient();
            smtp.Credentials = new NetworkCredential("fbetulyilmaz1@gmail.com","youtube1.");
            smtp.Port = 587;
            smtp.Host = "smtp.gmail.com";
            smtp.EnableSsl = true;

            try
            {
                smtp.Send(mailim);
                TempData["Message"] = "Mesajınız iletilmiştir. En kısa zamanda size geri dönüş sağlanacaktır.";
            }
            catch (Exception ex)
            {
                TempData["Message"] = "Mesaj gönderilemedi.Hata nedeni:" + ex.Message;
            }

            return View();

        }
    }
}